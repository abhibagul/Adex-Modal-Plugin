$(document).ready(function(){

	$('a').click(function(){

		var elem = $(this).attr('data-sect');
		var elem = '.' + elem;
		
		$('.col-sm-9 div').attr('style','display:none;');
		$(elem).fadeIn(0);
	});



	$('.hassub a').click(function(){

		$(this).parent('li').children('ul').slideToggle();
		
	});


});

	function showul(){
		$('ul ul').slideDown();
	}